let jumpImg;
let cloudImg;
let headImg;
let shoulderImg;
let legImg;

function preload(){
  jumpImg = loadImage("Person_Jumping.webp");
  cloudImg = loadImage("Cloud_Background.webp");
  headImg = loadImage("Man_touching_Head.jpg");
  shoulderImg = loadImage("Shoulder_Stretch.jpg")
  legImg = loadImage("Leg_Stretch.jpg");
  
}

function setup() {
  createCanvas(720, 400);
}

function draw() {
  background(162, 218, 255);
  image(cloudImg, 0, 0, 720, 400);
//First Box
  rect(360, 200, 150, 150);
  image(jumpImg, 360, 200, 150, 150);
//Second Box
  rect(160, 200, 150, 150);
  image(headImg, 160, 200, 150, 150);
//Third Box
  rect(160, 25, 150, 150);
  image(shoulderImg, 160, 25, 150, 150);
//Fourth Box
  rect(360, 25, 150, 150);
  image(legImg, 360, 25, 150, 150);
}