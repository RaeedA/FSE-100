


let bx;
let by;
let fishSize = 12.5;
let bucketSize = 100;
let overBox = false;
let locked = false;
let scoreCounted = false;
let xOffset = 0.0;
let yOffset = 0.0;
let bucketImg;
let fishImg;
let scoreCount = 0;
let fish;

function preload() {
  bucketImg = loadImage("CartoonBucket2.png");
  fishImg = loadImage("Cartoon_Fish.png");
}



function setup() {
  createCanvas(720, 400);
  bx = random(0, 720);
  by = random(0, 400);
  rectMode(RADIUS);
  strokeWeight(2);
  
  
}


function draw() {
  let fish = rect(bx, by, fishSize, fishSize);
  fishSize = random(fishSize, 40);
//Instantiate used colors
  let c1 = color(100, 100, 100);
  let c2 = color(500, 250, 150);
//Draws background
  background(35, 150, 250);
//Draws bucket dropzone
  fill(c1);
  rect(50,290,50,40)
  noFill();
  fill(109,302,327);
  noFill();
//Draws fish sprite
  image(fishImg, bx, by, fishSize, fishSize);
  noFill();
  fish = rect(bx, by, fishSize, fishSize);
  image(bucketImg,0,250,bucketSize,bucketSize);
//Test if the cursor is over the box
  if (
    mouseX > bx - fishSize &&
    mouseX < bx + fishSize &&
    mouseY > by - fishSize &&
    mouseY < by + fishSize
  ) {
    overBox = true;
    if (!locked) {
      fill(109,302,327);
    }
  } else {
    stroke(35, 150, 250);
    fill(c2);
    overBox = false;
  }

  //translate(width / 4, height / 4);
  //translate(p5.Vector.fromAngle(millis() / 1000, 50));
//Checks if fish is in bucket
    if (bx > 0   &&
        bx < 75  &&
        by > 250 &&
        by < 310 
       ) {
      fill(c1);
      //fish = rect(bx, by, boxSize, boxSize);
      scoreCount++;
      scoreCounted = true;
      rect(bx + 1000, by + 1000, fishSize, fishSize);
      print(scoreCount);
      noLoop();

    }
  
}


function mousePressed() {
  let c3 = color(100, 239, 199);
  if (overBox) {
    locked = true;
    fill(109,302,327);
  } else {
    locked = false;
    fill(139,12,347);
  }
  xOffset = mouseX - bx;
  yOffset = mouseY - by;
}

function mouseDragged() {
  if (locked) {
    bx = mouseX - xOffset;
    by = mouseY - yOffset;
  }
}

function mouseReleased() {
  locked = false;
}
/*function shapeDisappear(rect1){
  let backgroundColor = color(35, 50, 100);
  if (bx = 50) {
    rect1.fill(backgroundColor);
  }
  */




